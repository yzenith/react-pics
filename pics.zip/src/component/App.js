import React from "react";
import Test from "./Test";

const App = () => {
  return (
    <div>
      <Test />
    </div>
  );
};

export default App;
